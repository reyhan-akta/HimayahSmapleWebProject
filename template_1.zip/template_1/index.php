<?php

 include('web_site/header.php');
 include('web_site/banner.php');
 include('web_site/body.php');
 include('web_site/footer.php');
 
?>