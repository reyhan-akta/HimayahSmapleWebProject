
<div class="banner_wrapper">
    <div class="banner_left_arrow"><i class="fa fa-angle-left" aria-hidden="true"></i></div>
    <div class="banner_right_arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></div>
<img src="assets/banner_1.jpg">
    <div class="banner_left_arrow"></div>
    <div class="right_left_arrow"></div>
 <div class="banner_overlay">
    <div class="banner_content_wrapper">
        <h2>Lorem Ipsum</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        
        <div class="second_banner_button_wrapper">
            <div class="second_b_button_box" style="padding-right:5px;">1500</div> 
            <div class="second_b_button_box">Projects </div>
        </div>
        <div class="banner_buttons_wrapper">
            <div class="banner_button"><!--<i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;تطوع--></div>&nbsp;&nbsp;&nbsp;&nbsp;
            <div class="banner_button"></div>
        </div>
    </div>
 </div>   
<div class="tiny_images_box_wrapper">
     <div class="image_box" onclick="setFrameOnBoxImage(0);">
        <img src="assets/banner_1.jpg">
     </div>
     <div class="image_box" onclick="setFrameOnBoxImage(1);">
     <img src="assets/banner_2.jpg">
     </div>
</div>
<div class="banner_timer_bar"></div>
</div>